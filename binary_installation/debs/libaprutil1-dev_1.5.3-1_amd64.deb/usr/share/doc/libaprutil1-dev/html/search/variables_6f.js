var searchData=
[
  ['open',['open',['../structapr__dbd__driver__t.html#a911ce972cd9c1dbbcf770aed475e6428',1,'apr_dbd_driver_t::open()'],['../structapr__dbm__type__t.html#a4695443269822d7ca9208bd6579d3635',1,'apr_dbm_type_t::open()']]]
];
