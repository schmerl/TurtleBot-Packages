var searchData=
[
  ['thread_20safe_20fifo_20bounded_20queue',['Thread Safe FIFO bounded queue',['../group___a_p_r___util___f_i_f_o.html',1,'']]],
  ['thread_20pool_20routines',['Thread Pool routines',['../group___a_p_r___util___t_p.html',1,'']]],
  ['text',['text',['../structapr__text.html#a37a262695c36f740a7777ea9dd0b699d',1,'apr_text']]],
  ['threads',['threads',['../structapr__memcache__stats__t.html#a4e2a4875902e032a56de9ac58315f372',1,'apr_memcache_stats_t']]],
  ['time',['time',['../structapr__memcache__stats__t.html#adc02da0e6bfc619cd7eaebfae94404ff',1,'apr_memcache_stats_t']]],
  ['tm',['tm',['../unionapr__anylock__t_1_1apr__anylock__u__t.html#af08254c9ff8d2152276040037cd8ee53',1,'apr_anylock_t::apr_anylock_u_t']]],
  ['tm_5flock',['tm_lock',['../structapr__anylock__t.html#a047e5c4d930f359618a96fd5e857f851',1,'apr_anylock_t']]],
  ['total_5fconnections',['total_connections',['../structapr__memcache__stats__t.html#a47413a65552fa02fcc8adb74b3d0b8c0',1,'apr_memcache_stats_t']]],
  ['total_5fitems',['total_items',['../structapr__memcache__stats__t.html#a298fd199bee38cd658d54f6099e9fb58',1,'apr_memcache_stats_t']]],
  ['transaction_5fmode_5fget',['transaction_mode_get',['../structapr__dbd__driver__t.html#a3f749fdff0337dcab151af585e097c8f',1,'apr_dbd_driver_t']]],
  ['transaction_5fmode_5fset',['transaction_mode_set',['../structapr__dbd__driver__t.html#a2737c71d4629ae1b9860b0043fdab720',1,'apr_dbd_driver_t']]],
  ['type',['type',['../structapr__bucket.html#ac27fa5ce798e688ad243ebe1615937fc',1,'apr_bucket::type()'],['../structapr__dbm__t.html#a27287213e7ebe16d9945207a13300faf',1,'apr_dbm_t::type()']]]
];
