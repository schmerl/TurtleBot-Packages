var searchData=
[
  ['i18n_20translation_20library',['I18N translation library',['../group___a_p_r___x_l_a_t_e.html',1,'']]],
  ['init',['init',['../structapr__dbd__driver__t.html#aee4cda10b8f3c7680d3f8fe9d9835d6e',1,'apr_dbd_driver_t']]],
  ['is_5finitialized',['is_initialized',['../structapr__uri__t.html#a6f77dda6db6c31c2c3652f6026ea6b73',1,'apr_uri_t']]],
  ['is_5fmetadata',['is_metadata',['../structapr__bucket__type__t.html#a34cef542a8eee5bb734ba8dcd8329711',1,'apr_bucket_type_t']]]
];
