var searchData=
[
  ['get_5fentry',['get_entry',['../structapr__dbd__driver__t.html#a21742ca8a1b183de2a93ca04d030843f',1,'apr_dbd_driver_t']]],
  ['get_5fhits',['get_hits',['../structapr__memcache__stats__t.html#a6d3b60bc77c024259a2e9dfb1e35bfd7',1,'apr_memcache_stats_t']]],
  ['get_5fmisses',['get_misses',['../structapr__memcache__stats__t.html#affaa2901db1db585fca3cfa77fcb0230',1,'apr_memcache_stats_t']]],
  ['get_5fname',['get_name',['../structapr__dbd__driver__t.html#af8201f5eac24c7120b052c7a312f0126',1,'apr_dbd_driver_t']]],
  ['get_5frow',['get_row',['../structapr__dbd__driver__t.html#a93b4e127622c1f118da3855c518941cc',1,'apr_dbd_driver_t']]],
  ['getusednames',['getusednames',['../structapr__dbm__type__t.html#a9247cfe582aaf18915bb8552cd5c6bc7',1,'apr_dbm_type_t']]]
];
