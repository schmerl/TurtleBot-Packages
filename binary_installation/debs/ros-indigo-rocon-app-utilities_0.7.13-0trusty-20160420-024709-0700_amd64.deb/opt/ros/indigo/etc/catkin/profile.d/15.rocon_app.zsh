# generated from rocon_app_utilities/env-hooks/15.rocon_app_utilities.zsh.em

. "/opt/ros/indigo/share/rocon_app_utilities/shells/env.zsh"
