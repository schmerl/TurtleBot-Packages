# generated from rocon_python_comms/env-hooks/15.rospair.bash.em

. "/opt/ros/indigo/share/rocon_python_comms/completion/rospairbash"
