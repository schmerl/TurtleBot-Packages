The URDF (U-Robot Description Format) library
  provides core data structures and a simple XML parsers
  for populating the class data structures from an URDF file.

For now, the details of the URDF specifications reside on
  http://ros.org/wiki/urdf

