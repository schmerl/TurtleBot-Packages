from ._GetPlatformInfo import *
