export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/ros/indigo/lib/python2.7/dist-packages
