#!/usr/bin/env python
#
# License: BSD
#   https://raw.github.com/robotics-in-concert/rocon_app_platform/master/rocon_apps/LICENSE
#
##############################################################################
# Imports
##############################################################################
