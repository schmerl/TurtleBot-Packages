# ============================================================== #
# This is now just a stub, importing the real module which lives #
# under wx.lib.agw.
# ============================================================== #

"""
Attention! HyperLinkCtrl now lives in wx.lib.agw, together with
its friends in the Advanced Generic Widgets family.

Please update your code!
"""

from wx.lib.agw.hyperlink import *