#include <aknbitmapanimation.h>
