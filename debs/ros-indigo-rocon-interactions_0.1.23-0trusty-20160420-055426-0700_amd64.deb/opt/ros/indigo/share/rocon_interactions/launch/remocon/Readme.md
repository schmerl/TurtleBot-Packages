
These are not intended to be launched directly from the command line (hence the .xml extension).

The rocon remocon will use launch these for certain interactions that specify them.

