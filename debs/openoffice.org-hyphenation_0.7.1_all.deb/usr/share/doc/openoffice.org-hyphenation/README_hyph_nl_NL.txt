README.txt (Nederlands/English)

[Nederlands]
********************************************************************************
* U wordt vriendelijk verzocht om dit bestand README.TXT mee te distribueren   *
* bij iedere kopie de van de Nederlandstalige Myspell woordenlijst (nl_NL.dic  *
* en nl_NL.aff), het Nederlandstalige Altlinux woordafbreekpatronenbestand     *
* hyph_nl.dic, en/of het Nederlandstalige medische supplement med-NL.dic.      *
* Gebruik en verspreiding van deze bestanden is slechts toegestaan onder de    *
* voorwaarden van de in dit readme bestand genoemde licenties.                 *                              
********************************************************************************


Over het Nederlandstalige AltLinux woordafbreekpatronenbestand hyph_nl.dic: 
--------------------------------------------------------------------------------
Dit bestand met afbreekpatronen is afkomstig van Piet Tutelaer; bij hem berust 
ook het oorspronkelijke copyright. Het is door hem beschikbaar gesteld onder de 
GPL versie 2 licentie. 

Arthur Buijs heeft de wijzigingen aangebracht om het geschikt te maken voor 
gebruik met de ALTLinux hyphenator.


Meer informatie:
--------------------------------------------------------------------------------
Voor vragen en suggesties, schrijf aan Simon Brouwer: simonbr@openoffice.org

Voor informatie in het Nederlands over OpenOffice.org: http://nl.openoffice.org



[English] 
Word lists version 17 july 2005

********************************************************************************
* You are kindly requested to keep a copy of this file with every copy you     *
* make of the Dutch Myspell dictionary (nl_NL.dic and nl_NL.aff), the Dutch    *
* hyphenation patterns (hyph_nl.dic) and/or the Dutch medical dictionary       *
* (med-NL.dic)                                                                 *
* Use and/or distribution of these files is only allowed in accordance to the  *
* license conditions as stated in this readme file.                            *
********************************************************************************


About the Dutch AltLinux hyphenation pattern file hyph_nl.dic: 
--------------------------------------------------------------------------------
It is based on the TeX hyphenation patterns file that created and original 
copyright by Piet Tutelaer.

It is made available under the conditions of the GPL version 2 license. 

Arthur Buijs modified the hyphenation patterns file so that it can be used with 
the ALTLinux hyphenator.


More information:
--------------------------------------------------------------------------------
For questions and suggestions, write email to Simon Brouwer: simonbr@openoffice.org

For information in Dutch on OpenOffice.org: see http://nl.openoffice.org

For information in English on OpenOffice.org: see http://www.openoffice.org
