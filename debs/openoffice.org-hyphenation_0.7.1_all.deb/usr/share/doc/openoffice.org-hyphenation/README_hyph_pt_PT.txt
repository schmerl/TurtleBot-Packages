Hyphenation dictionary
----------------------

Language: Portuguese (pt PT).
Origin:   Based on the TeX hyphenation tables by Pedro J. de Rezende <rezende@dcc.unicamp.br> (Brazilian) and tuned up by J.Joao Dias Almeida <jj@di.uminho.pt>
License:  GNU GPL license.
Author:   conversion author is Paulo Morgado <paulo.morgado@vizzavi.pt>


This dictionary is based on syllable matching patterns and therefore should
be usable under other variations of Portuguese.

HYPH pt PT hyph_pt_PT

