Hellenic hyphenation dictionary for OpenOffice.org 1.1.0
--------------------------------------------------------

Language:	Greek a.k.a. Hellenic (el GR).  
Version:	1.1b

License:	LGPL
Author:		InterZone <info@interzone.gr>

This dictionary should be usable only for monotonic Greek (not polytonics, neither archaic). There may be some problems with words starting with accented vowels, feedback is welcome. Words in quotes do not hyphenate, but it seems like a problem with OpenOffice and not the hyphenation dictionary.

