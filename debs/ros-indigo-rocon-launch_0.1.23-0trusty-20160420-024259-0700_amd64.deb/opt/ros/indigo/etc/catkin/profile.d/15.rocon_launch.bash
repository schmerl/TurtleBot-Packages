# generated from rocon_launch/env-hooks/15.rocon_launch.bash.em

. "/opt/ros/indigo/share/rocon_launch/shells/env.bash"
